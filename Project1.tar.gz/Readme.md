#Chat_Server_Application using Sockets

#server.py
bash
```
python3 server.py

```
To start the server                                                                             
                                                                                                <PORT> <HOST> 
You would be presend with the following message:  Chat server is listening on port and Host ... 49644 linprog6.cs.fsu.edu

You can also broadcast messages by entering message in the console..

#client.py
bash
```
python3 client.py <HOST> <PORT>
```
Output:
Connected to the chat server.
Enter your username: <USERNAME>

Enter the username for client. and Text broadcasting message between server and client
